import React from 'react'
import NavBar from '../Components/OM/components/Navbar'
import Hero from '../Components/OM/components/Hero'
import Plan from '../Components/OM/components/Plan'
import Technical from '../Components/OM/components/Technical'
import ImageSlider from '../Components/OM/components/ImageSlider'
import Footer from '../Components/OM/components/Footer'




function Test() {
  return (
    <div>
        {/* <NavBar /> */}
        <Hero />
        <Plan />
        <Technical />
        <ImageSlider/>
        <Footer/>

    </div>
  )
}

export default Test

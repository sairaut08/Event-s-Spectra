import { createAsyncThunk, createSlice } from "@reduxjs/toolkit"
import toast from "react-hot-toast";

import axiosInstance from "../../config/axiosInstance";
const initialState = {
    clubList: []
}

export const getAllClubs = createAsyncThunk("/clubs/getAllClubs", async (data) => {
    try {
        const response = axiosInstance.get("/clubs", data);
        toast.promise(response, {
            loading: 'Wait! fetching all Clubs',
            success: (data) => {
                return data?.data?.message;
            },
            error: 'Failed to load clubs'
        });
        return (await response).data.clubs;
    } catch(error) {
        console.log(error);
        toast.error(error?.response?.data?.message);
    }
})




const clubSlice = createSlice({
    name: "clubs",
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder.addCase(getAllClubs.fulfilled, (state, action) => {
            console.log(action.payload)
            if(action?.payload) {
                state.clubList = [...action.payload];
            }
        })
    }
});

export default clubSlice.reducer;
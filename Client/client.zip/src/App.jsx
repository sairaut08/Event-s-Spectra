import './App.css'

import { Route, Routes } from 'react-router-dom'

import RequireAuth from './components/Auth/RequireAuth'
import ClubList from './pages/clubs/ClubList'
import Home from './pages/Home'
import Signin from './pages/Signin'
import Signup from './pages/Signup'


function App() {

  return (
    <Routes>
      <Route path='/' element={<Home />} />
      {/* <Route path='/about' element={<Aboutus />} /> */}
      <Route path='/signup' element={<Signup />} />
      <Route path='/signin' element={<Signin />} />
      <Route path='/clubs' element={<ClubList />} />
      {/* <Route path='/course/description' element={<CourseDescription />} /> */}

      <Route element={<RequireAuth allowedRoles={["ADMIN", "USER"]} />}>
       


      
      </Route>

      {/* <Route element={<RequireAuth allowedRoles={["ADMIN"]} />}>
        <Route path="/course/create" element={<CreateCourse />} />
        {/* <Route path="/course/addlecture" element={<AddLecture />} /> 
      </Route>
       */}

      
    </Routes>
  )
}

export default App
